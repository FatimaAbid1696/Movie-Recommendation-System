import pandas as pd

from sklearn.feature_extraction.text import CountVectorizer

from sklearn.metrics.pairwise import cosine_similarity


# READ MOVIE DATASET
movies = pd.read_csv('movies.csv')


# HANDLE EMPTY GENRES
movies['genres'] = movies['genres'].fillna('')


# CONVERT TEXT INTO NUMERICAL VECTORS
cv = CountVectorizer()

matrix = cv.fit_transform(movies['genres'])


# CALCULATE SIMILARITY BETWEEN MOVIES
similarity = cosine_similarity(matrix)


# RECOMMENDATION FUNCTION
def recommend(movie_name):

    recommendations = []

    try:

        movie_index = movies[
            movies['title'] == movie_name
        ].index[0]

        distances = similarity[movie_index]

        movie_list = sorted(

            list(enumerate(distances)),

            reverse=True,

            key=lambda x:x[1]

        )

        for movie in movie_list[1:]:

            similarity_score = movie[1]

            if similarity_score > 0.6:

                recommendations.append(

                    movies.iloc[movie[0]].title

                )

        return recommendations[:10]

    except:

        return ["Movie not found"]