from flask import Flask, render_template, request, redirect, session, flash
from flask_sqlalchemy import SQLAlchemy
import pandas as pd

from recommendation import recommend

# ==================================
# CREATE FLASK APP
# ==================================
import os
print("DB PATH:", os.path.abspath("database.db"))

app = Flask(__name__)

app.secret_key = "movieprojectsecret"

# ==================================
# DATABASE CONFIG
# ==================================

import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app.config['SQLALCHEMY_DATABASE_URI'] = \
    'sqlite:///' + os.path.join(BASE_DIR, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

with app.app_context():
    db.create_all()

# ==================================
# LOAD MOVIES DATASET
# ==================================

movies = pd.read_csv('movies.csv')

# ==================================
# DATABASE TABLES
# ==================================

class User(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    username = db.Column(
        db.String(100),
        unique=True,
        nullable=False
    )

    password = db.Column(
        db.String(100),
        nullable=False
    )


class Rating(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    username = db.Column(
        db.String(100)
    )

    movie_title = db.Column(
        db.String(300)
    )

    rating = db.Column(
        db.Integer
    )


class Watchlist(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    username = db.Column(
        db.String(100)
    )

    movie_title = db.Column(
        db.String(300)
    )

class Admin(db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    username = db.Column(
        db.String(100),
        unique=True
    )

    password = db.Column(
        db.String(100)
    )

# ==================================
# CREATE TABLES
# ==================================

with app.app_context():
    db.create_all()


with app.app_context():

    admin = Admin.query.filter_by(
        username='admin'
    ).first()

    if not admin:

        admin = Admin(
            username='admin',
            password='admin123'
        )

        db.session.add(admin)

        db.session.commit()

# ==================================
# ROUTES
# ==================================

@app.route('/')
def start():

    return redirect('/welcome')

# ==================================
# WELCOME PAGE
# ==================================

@app.route('/welcome')
def welcome():

    return render_template('welcome.html')

# ==================================
# HOME PAGE
# ==================================

@app.route('/home')
def home():

    if 'username' not in session:
        return redirect('/login')

    movie_list = movies.head(500).to_dict(
        orient='records'
    )

    return render_template(
        'index.html',
        movies=movie_list
    )

# ==================================
# SEARCH MOVIES
# ==================================

@app.route('/search')
def search():

    if 'username' not in session:
        return redirect('/login')

    query = request.args.get('query')

    filtered_movies = movies[
        movies['title'].str.contains(
            query,
            case=False,
            na=False
        )
    ]

    movie_list = filtered_movies.to_dict(
        orient='records'
    )

    if len(movie_list) == 0:

        return render_template(
            'index.html',
            movies=[],
            no_result=True,
            query=query
        )

    return render_template(
        'index.html',
        movies=movie_list,
        no_result=False
    )

# ==================================
# REGISTER
# ==================================

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        username = request.form['username']
        password = request.form['password']

        existing_user = User.query.filter_by(
            username=username
        ).first()

        if existing_user:

            flash("Username already exists")

            return redirect('/register')

        new_user = User(
            username=username,
            password=password
        )

        db.session.add(new_user)
        db.session.commit()

        flash("Registration Successful")

        return redirect('/login')

    return render_template('register.html')

# ==================================
# LOGIN
# ==================================

@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(
            username=username,
            password=password
        ).first()

        if user:

            session['username'] = username

            flash("Welcome " + username, "success")
            session.pop('_flashes', None)

            return redirect('/home')

        else:

            flash("Invalid Username or Password")

            return redirect('/login')

    return render_template('login.html')

# ==================================
# LOGOUT
# ==================================

@app.route('/logout')
def logout():

    # clear user session
    session.pop('username', None)

    # clear flash messages so they don't appear again
    session.pop('_flashes', None)

    # redirect directly (clean UX)
    return redirect('/welcome?logout=success')

# ==================================
# RECOMMENDATION
# ==================================

@app.route('/recommend/<movie_name>')
def recommendation(movie_name):

    if 'username' not in session:
        return redirect('/login')

    recommendations = recommend(
        movie_name
    )

    return render_template(
        'recommend.html',
        recommendations=recommendations,
        movie_name=movie_name
    )

# ==================================
# ADD TO WATCHLIST
# ==================================

@app.route('/add_watchlist/<movie_name>')
def add_watchlist(movie_name):

    if 'username' not in session:
        return "login_required"

    existing = Watchlist.query.filter_by(
        username=session['username'],
        movie_title=movie_name
    ).first()

    if existing:
        return "exists"

    new_item = Watchlist(
        username=session['username'],
        movie_title=movie_name
    )

    db.session.add(new_item)
    db.session.commit()

    return "added"

# ==================================
# WATCHLIST PAGE
# ==================================

@app.route('/watchlist')
def watchlist():

    if 'username' not in session:
        return redirect('/login')

    movies_list = Watchlist.query.filter_by(
        username=session['username']
    ).all()

    return render_template(
        'watchlist.html',
        movies=movies_list
    )

@app.route('/remove_watchlist/<int:id>')
def remove_watchlist(id):

    movie = Watchlist.query.get(id)

    db.session.delete(movie)

    db.session.commit()

    return redirect('/watchlist')


@app.route('/admin_login',
methods=['GET','POST'])

def admin_login():

    if request.method == 'POST':

        username = request.form['username']

        password = request.form['password']

        admin = Admin.query.filter_by(
            username=username,
            password=password
        ).first()

        if admin:

            session['admin'] = username

            return redirect('/admin')

        flash("Invalid Admin Login")

        return redirect('/admin_login')

    return render_template(
        'admin_login.html'
    )

@app.route('/admin')
def admin():

    if 'admin' not in session:

        return redirect('/admin_login')

    users = User.query.all()

    watchlists = Watchlist.query.all()

    return render_template(

        'admin.html',

        users=users,

        watchlists=watchlists
    )

# ==================================
# ADMIN LOGOUT
# ==================================

@app.route('/admin_logout')
def admin_logout():

    # Remove admin session
    session.pop('admin', None)

    # Optional: remove user session too
    session.pop('username', None)

    flash("Admin Logged Out Successfully")

    # Go back to website dashboard
    return redirect('/welcome')

# ==================================
# RUN APP
# ==================================

if __name__ == '__main__':

    app.run(debug=True)